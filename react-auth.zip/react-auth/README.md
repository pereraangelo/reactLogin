

LOGIN CREDENTIALS
 
email :lina@gmail.com  password:lina123   [can be verified from  src/common/user.js]

                        and
 
email :anne@aol.com  password:anne123


Steps to setup :

git clone

npm install

npm start         //to run the server

npm test          // to run test



Application consist following routes

 1 localhost:3000/
 
 
 2 localhost:3000/registration            


 3 localhost:3000/faq                    
 
 
 4 localhost:3000/aboutus/home      

  
 
 