/*
created this file to bypass jest test in authActions.test.js since it does not know localstorage.
*/

let localStorage = {};

export default {
    setItem(key, value) {
        return Object.assign(localStorage, {[key]: value});
    },
    getItem(key) {
        return localStorage[key];
    },
    clear() {
        localStorage = {};
    }
};