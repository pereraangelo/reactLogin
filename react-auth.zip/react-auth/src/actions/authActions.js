import * as types from '../common/actionTypes'
import USER from '../common/users'


/*----------- Set authentication action -----------*/

export const setAuthetication = (data) => (dispatch) => {
    dispatch({
     type: types.SET_AUTHENTICATION,
     payload: data,
   });
 };



/*----------- login action -----------*/
export function login (user) {
    

    let registeredUser= USER.filter(registeredUser=> {
        if (registeredUser.email === user.email) {
            if (registeredUser.password === user.password) {
                return registeredUser
            }
            return null

        }
        return null
    })

    if(registeredUser.length!==0){
        
     
        localStorage.setItem('jwtkey',registeredUser[0].token);
        localStorage.setItem('email',registeredUser[0].email); 
        localStorage.setItem("user", JSON.stringify(registeredUser[0]));

        
        
          return{
            type: types.LOGGED_IN,
            payload: {email: registeredUser[0].email, token: registeredUser[0].token,message:"You have successfully logged in."}
        }
 
    }
    else{
        return{
            type: types.WRONG_CREDENTIALS,
            payload: {email: user.email,message:"email or password is invalid."} 
        }
    }



}



/*----------- logout action -----------*/
export function logout () {


    localStorage.clear();
   return {
        type:types.LOGGED_OUT,
            payload:false
    }

}


/*----------- register action -----------*/
export function register (user) {
        let registeredUser= USER.filter(registeredUser=> {
            if (registeredUser.email === user.email) {
                return registeredUser
            }
            return null
            })

            if(registeredUser.length!==0){
                return{
                    type: types.ALREADY_A_USER,
                    payload: "You already have an account.Please return to login page."
                }
                }
            else{    
                return{  
                        type: types.REGISTER,
                        payload: {email: user.email, userName: user.userName,password:user.password,message:"Currently unable to register.Please try again later."}
                }
}

}



/*----------- reset store states to initial state action -----------*/
export function reset () {

return {
    type:types.RESET_STATES,
        payload:{}
}

}


