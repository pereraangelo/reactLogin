 import * as actions from './authActions'
import * as types from '../common/actionTypes'
import USER from '../common/users'
import localStorageMock from '../mock-local-storage';

window.localStorage = localStorageMock;

describe('auth actions', () => {

    describe('login action',()=>{
        
        it('successfully logged in if provided correct credentials', () => {
            
            const user ={email:USER[0].email,password:USER[0].password};
            const expectedAction = {
                type: types.LOGGED_IN,
                payload:{token:USER[0].token,email:USER[0].email,message:"You have successfully logged in."}
            }
            
            expect(actions.login(user)).toEqual(expectedAction)
        })
        it('throw error if Wrong Credentials provided', () => {
            const user ={email:'jofd3hn@gmail.com',password:'pass123'};
            const expectedAction = {
                type: types.WRONG_CREDENTIALS,
                payload:{email: user.email,message:"email or password is invalid."} 
            }
            expect(actions.login(user)).toEqual(expectedAction)
        })
    })

    describe('logout action',()=>{

        it('should logout user ', () => {

            const expectedAction = {
                type: types.LOGGED_OUT,
                payload:false
            }
            expect(actions.logout()).toEqual(expectedAction)
        })
    })

    describe('register new user action',()=>{
        it('successfully register if provided data is correct', () => {
            
            const user ={email: "john@gmail.com", userName: "John",password:"pass123",message:"Currently unable to register.Please try again later."};
            const expectedAction = {
                type: types.REGISTER,
                payload:user
            }
             expect(actions.register(user)).toEqual(expectedAction)
        })

        it('throw error if User already registered', () => {
            const user ={email:'anne@aol.com',password:'anne123',userName:"AnneTaylor"};
            const expectedAction = {
                type: types.ALREADY_A_USER,
                payload: "You already have an account.Please return to login page."
            }
            expect(actions.register(user)).toEqual(expectedAction)
        })
    })

    describe('reset initial states',()=>{
        it('should reset states to initial states', () => {
            
             const expectedAction = {
                type: types.RESET_STATES,
                payload:{}
            }
            expect(actions.reset()).toEqual(expectedAction)
        })
        
    })


})