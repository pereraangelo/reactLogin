//Mock Data

const USER = [
  {
    userName: "LinaDaniel",
    email: "lina@gmail.com",
    password: "lina123",
    token: "rabctfefusg6ydfyrg",
  },
  {
    userName: "AnneTaylor",
    email: "anne@aol.com",
    password: "anne123",
    token: "hysk4hu6nsh4nfjlsm",
  },
];

export default USER;
 