
 import *  as types from '../common/actionTypes'
import authReducer from './authReducer';

const initialState= {
    isAuthenticated:false,
    user:{},
    authenticationError:'',
    alert:"",
    newUser:{},
    potentialUser:"",
    alreadyAuser:false,
    loggingInProgress: false,
  }

describe("auth reducer", () => {
  
    it("should return the initial state", () => {
        expect(authReducer(undefined,{type:'unexpected'})).toEqual({...initialState,isAuthenticated:false,user:{},authenticationError:''});
    });

    it('it can handle login', () => {
        const testData = {...initialState,isAuthenticated:true,user:{email:'email@email.com', token:'kasdkjfu134234'},authenticationError:'',alert:"You have successfully logged in.",loggingInProgress: true,};
            
            const newState = authReducer(undefined, {
                type:types.LOGGED_IN,
                payload:{email:'email@email.com', token:'kasdkjfu134234'}
            });

        expect(newState).toEqual(testData);
    });

    it('it can authenticate ', () => {
        const testData = {...initialState,isAuthenticated:true,user:{email:'email@email.com', token:'kasdkjfu134234'},authenticationError:'',alert:"You have successfully logged in."};
            
            const newState = authReducer(undefined, {
                type:types.SET_AUTHENTICATION,
                payload:{email:'email@email.com', token:'kasdkjfu134234'}
            });

        expect(newState).toEqual(testData);
    });


    it('it can handle logout', () => {
        const testData = {...initialState,isAuthenticated:false,user:{},authenticationError:''};
            
            const newState = authReducer(undefined, {
                type:types.LOGGED_OUT,
                payload:false
            });

        expect(newState).toEqual(testData);
    });
    

    it('it can handle Wrong Crendentials', () => {
        const testData = {...initialState,authenticationError:'email or password is invalid.',potentialUser:"john@gmail.com"};
            
            const newState = authReducer(undefined, {
                type:types.WRONG_CREDENTIALS,
                payload:{email: "john@gmail.com",message:"email or password is invalid."}
            });

        expect(newState).toEqual(testData);
    });

    it('it can handle register a user', () => {
        const testData = {...initialState,alreadyAuser:false,newUser:{email:'john@gmail.com', password:'pass123',userName:"John",message:"Currently unable to register.Please try again later."},potentialUser:"",alert:"Currently unable to register.Please try again later.",};
            
            const newState = authReducer(undefined, {
                type:types.REGISTER,
                payload:{email:'john@gmail.com', password:'pass123',userName:"John",message:"Currently unable to register.Please try again later."}
            });

        expect(newState).toEqual(testData);
    });

    it('it can handle already registered users', () => {
        const testData = {...initialState,isAuthenticated:false,alert:"You already have an account.Please return to the login page.",alreadyAuser:true};
            
            const newState = authReducer(undefined, {
                type:types.ALREADY_A_USER,
                payload:"You already have an account.Please return to the login page."
            });

        expect(newState).toEqual(testData);
    });

  
});
