import * as types  from '../common/actionTypes'

const initialState= {
    isAuthenticated:false,
    user:{},
    authenticationError:'',
    alert:"",
    newUser:{},
    potentialUser:"",
    alreadyAuser:false,
    loggingInProgress: false,
  }
  const authReducer = (state = 
    initialState, 
    action) => {
  
    switch (action.type) {
        case types.LOGGED_IN:
            state = {
                ...state,
                isAuthenticated:true,
                user:action.payload,
                authenticationError:'',
                alert:"You have successfully logged in.",
                loggingInProgress: true,
  
            }
            break;
        case types.SET_AUTHENTICATION:
            state = {
                ...state,
                isAuthenticated: true,
                user: action.payload,
                authenticationError:'',
                alert:"You have successfully logged in.",
                loggingInProgress: false,
            }
            break
        
        case types.LOGGED_OUT:
            state = {
                ...state,
                isAuthenticated:action.payload,
                user:{},
                authenticationError:''
  
            }
            break;
        case types.WRONG_CREDENTIALS:
            state={
                ...state,
                authenticationError:action.payload.message,
                potentialUser:action.payload.email,
                loggingInProgress: false,
            };
            break;
        case types.ALREADY_A_USER:
            state={
                ...state,
                alert:action.payload,
                alreadyAuser:true
            };
            break;            
        case types.REGISTER:
            state={
                ...state,
                newUser:action.payload,  
                alert:action.payload.message,
                potentialUser:"",
                alreadyAuser:false
               
            };
           break;  
        case types.REGISTER:
            state={
                ...state,
                 
                alreadyAuser:false
               
            };
           break;   
        case types.RESET_STATES:
            state =initialState
  
          
           break;  
        default:
            state={
                ...state,
            }
  
    }
    return state
  }
  
  export default authReducer
  