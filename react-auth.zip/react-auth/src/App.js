import React, { useEffect } from "react";
import FAQ from "./components/FAQ/Faq";
import Nav from "./components/Nav/Nav";
import Login from "./components/Login/Login";
import { Route, Routes ,Navigate} from "react-router-dom";
import NotFound from "./components/NotFound/NotFound";
import Registration from "./components/Registration/Registration";
import Home from "./components/Home/Home";
import { connect } from "react-redux";
import { store } from "./createStore";
import { setAuthetication } from "./actions/authActions";

export function App(props) {
  const { isAuthenticated } = props;
 
  useEffect(() => {
    if (localStorage.jwtkey) {
       store.dispatch(setAuthetication(JSON.parse(localStorage.user))); 
       console.log("userdetaisl",JSON.parse(localStorage.user))
    }
  }, []);

  return (
    <div className="">
      <Nav />
      <Routes>
        <Route path="/" element={isAuthenticated ? <Navigate to="/home" replace />:<Login />} />
        <Route path={"/registration"} element={isAuthenticated ? <Navigate to="/home" replace />:<Registration />} />
        <Route exact path={"/FAQ"} element={<FAQ />} />
        <Route path="*" element={<NotFound />} />
        <Route path="/home" element={!isAuthenticated ? <Navigate to="/" replace />:<Home />} />
      </Routes>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    isAuthenticated: state.auth.isAuthenticated,
  };
};

export default connect(mapStateToProps)(App);
