import React from 'react'
import  {Login} from './login'
import { shallow} from 'enzyme'
import ReactDOM from 'react-dom'
import renderer from 'react-test-renderer'
import {MemoryRouter} from "react-router";
import { findByTestAtrr, simulateChangeOnInput } from '../../Utils';

const defaultProps={
    authenticationError: "",
    isAuthenticated: false,
    login: jest.fn(),
    logout: jest.fn(),
    register: jest.fn(),
    reset: jest.fn(),
}
 



describe('Login Component',()=>{
  
    const wrapper = shallow( <Login {...defaultProps} />);

    it('Login page should load without crahing',()=>{

        const div = document.createElement('div');
        ReactDOM.render(<MemoryRouter ><Login/></MemoryRouter>, div);

    });
    
    it('login component matches the snapshot',()=>{
        const tree=renderer.create(<MemoryRouter ><Login/></MemoryRouter>).toJSON()
        expect(tree).toMatchSnapshot()
    });
      

    it('check form contains 2 inputs, 1 button, 3 links',()=>{

        expect(wrapper.find('form').length).toBe(1)
        expect(wrapper.find('input').length).toBe(2);
        expect(wrapper.find('button').length).toBe(1);
        expect(wrapper.find('Link').length).toBe(3);

        expect(wrapper.containsMatchingElement(<input type="text" name="email"/>)).toEqual(true)
        expect(wrapper.containsMatchingElement(<input type="password" name="password"/>)).toEqual(true)
        expect(findByTestAtrr(wrapper, 'login').length).toBe(1); 
        expect(findByTestAtrr(wrapper, 'registration').length).toBe(1); 
        expect(findByTestAtrr(wrapper, 'forgot-password').length).toBe(1);
        expect(findByTestAtrr(wrapper, 'FAQ').length).toBe(1);
    })




    it('let fill the form',()=>{

        const emailInput            =   simulateChangeOnInput(wrapper,'email','john@gmail.com')
        const passwordInput         =   simulateChangeOnInput(wrapper,'password','pass123')

        expect(emailInput.props().value).toEqual('john@gmail.com')
        expect(passwordInput.props().value).toEqual('pass123')
   
    })
    


    it('shows password in plain text when eye button clicked',()=>{
        const togglePass = findByTestAtrr(wrapper, 'showPassword')
        togglePass.simulate('click') 
        const passwordField = findByTestAtrr(wrapper, 'password').props().type

        expect(passwordField).toEqual("text") 
    })



    it('redirect user to registration page',()=>{
        const faq = findByTestAtrr(wrapper, 'registration').props().to
        expect(faq).toEqual("/registration")
         
    })


    // it('redirect user to forgot password page',()=>{
    //     const faq = findByTestAtrr(wrapper, 'forgot-password').props().to
    //     expect(faq).toEqual("/forgot-password")
         
    // })

    
    it('redirect user to faq page',()=>{
        const faq = findByTestAtrr(wrapper, 'FAQ').props().to
        expect(faq).toEqual("/FAQ")
         
    })


 
})

  




