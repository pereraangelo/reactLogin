import React, { useState, useEffect } from "react";
import * as actions from "../../actions/authActions";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import eye from "../../assets/icons/eye.svg";

export function Login(props) {
  const {
    login,
    isAuthenticated,
    authenticationError,
    reset,
    setAuthetication,
  } = props;
  const [user, setUser] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [showPass, setShowPass] = useState(false);

  /*----------- input handler to set input values-----------*/
  const handleInput = (event) => {
    const target = event.target;
    const value = target.value;
    const name = target.name;

    setUser((preState) => ({ ...preState, [name]: value }));
  };

  /*----------- submit the loginform to login -----------*/
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateEmail()) {
      setError("");
      let userTemp = {
        email: user.email,
        password: user.password,
      };
      fetch(login(userTemp)).then(() => {
        setAuthetication(JSON.parse(localStorage.user));
      });
    } else {
      setError("Email is not valid");
    }
  };

  const validateEmail = () => {
    var re =
      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(user.email);
  };

  const togglePass = () => {
    setShowPass(!showPass);
  };
  useEffect(() => {
    reset();
    return () => {};
  }, []);

  return (
    <div className="center">
      <div className="login card">
        <h3 className="card-header  login-header">LOGIN</h3>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <input
                data-test="email"
                type="text"
                name="email"
                value={user.email}
                placeholder="Enter Email Address"
                onChange={handleInput}
                className={
                  "form-control" +
                  (error && (!user.email || !validateEmail())
                    ? " is-invalid"
                    : "")
                }
              />
              {error && (!user.email || !validateEmail()) ? (
                <span className="error ">
                  <i
                    className="fa fa-exclamation-triangle"
                    aria-hidden="true"
                  ></i>
                  {error}
                </span>
              ) : (
                <span></span>
              )}
            </div>

            <div className="form-group ">
              <div className="showPassword">
                {" "}
                <input
                  data-test="password"
                  type={showPass ? "text" : "password"}
                  name="password"
                  value={user.password}
                  placeholder="Enter Password"
                  onChange={handleInput}
                  className={
                    "form-control" +
                    ((error && !user.password) || authenticationError !== ""
                      ? " is-invalid"
                      : "")
                  }
                />
                <span
                  className="eyeContainer btn"
                  data-test="showPassword"
                  onClick={togglePass}
                >
                  <img src={eye} className="eye"></img>
                </span>
              </div>

              {authenticationError !== "" ? (
                <span className="error">
                  <i
                    className="fa fa-exclamation-triangle"
                    aria-hidden="true"
                  ></i>
                  {authenticationError}
                  <br />
                </span>
              ) : (
                <span></span>
              )}
            </div>

            <div className="form-group">
              <div className="form-group col loginBtnContainer">
                <button
                  className="myBtn btn btn-primary"
                  type="submit"
                  value="Login"
                  data-test="login"
                >
                  {" "}
                  <span className="skew-fix">LOGIN</span>{" "}
                </button>
              </div>
            </div>

            <div className="row justify-content-start">
              <div className="col-sm-6"> Don't have an account yet?&nbsp;</div>
              <div className="col-sm-6  ">
                {" "}
                <Link
                  to="/registration"
                  className="btn-link"
                  data-test="registration"
                >
                  Signup
                </Link>
              </div>
            </div>

            <div className="row">
              <div className="col-sm-7 ">Don't remember your password?&nbsp;</div>
              <div className="col-sm-5 ">
                <Link
                  to="/"
                  className=" btn-link pr-0"
                  data-test="forgot-password"
                >
                  Recover my Password
                </Link>
              </div>
            </div>
          </form>
        </div>
      </div>

      <Link
        to="/FAQ"
        className=" faq-button btn-link pr-0"
        data-test="FAQ"
      ></Link>
    </div>
  );
}
const mapStateToProps = (state) => {
  return {
    isAuthenticated: state.auth.isAuthenticated,
    authenticationError: state.auth.authenticationError,
  };
};

export default connect(mapStateToProps, actions)(Login);
