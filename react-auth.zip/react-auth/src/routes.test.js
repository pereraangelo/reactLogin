import React from 'react';
import { shallow } from 'enzyme';
import {App, Login, Registration, FAQ,NotFound } from './App';
import { Route } from 'react-router-dom';
 
let pathMap = {};
describe('routes using array of routers', () => {
  beforeAll(() => {
    const component = shallow(<App/>);
    pathMap = component.find(Route).reduce((pathMap, route) => {
        const routeProps = route.props();
        pathMap[routeProps.path] = routeProps.component;
        return pathMap;
      }, {});
  })
  it('should show Login component for / router (getting array of routes)', () => {

    expect(pathMap['/']).toBe(Login);
  })
  it('should show registration component for /registration router', () => {
    expect(pathMap['/registration']).toBe(Registration);
  })
  it('should show FAQ component for /FAQ router', () => {
    expect(pathMap['/FAQ']).toBe(FAQ);
  })
  // it('should show Home component for /Home router', ()=>{
  //   expect(pathMap['undefined']).toBe(NotFound);
  // })

  it('should show No match component for route not defined', ()=>{
      expect(pathMap['undefined']).toBe(NotFound);
  })
})